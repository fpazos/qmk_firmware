#pragma once

#include "quantum.h"

#if defined(KEYBOARD_lily58l_rev1)
  #include "rev1.h"
// #elif defined(KEYBOARD_planck_light)
//   #include "light.h"
#endif // Revisions
